# 内部状态

## 当前运行模式
- memory_mode: preview
- route_mode: auto_rule
- debug_mode: false
- safe_mode: false
- performance_mode: fast
- entry_mode: wechat

## 当前阶段
- current_version: v0.6.4
- active_task: 默认入口切换为微信群，单聊模式保留为可切换入口
- next_version: v0.6.4

## 规则边界
- 不自动污染长期记忆。
- 不绕过用户确认写入。
- 不让群聊替代正式学习。
- 不让互动氛围削弱纠错和任务边界。
- safe_mode=true 时禁止写入长期记忆。
