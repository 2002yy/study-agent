# package_project.ps1
# Creates release zip with forward-slash paths (PS5.1 + Python)
param(
    [string]$Version = "",
    [string]$OutputDir = "release",
    [switch]$IncludeTests = $true
)

$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot | Split-Path -Parent

if (-not $Version) {
    $stateFile = Join-Path $Root "memory\internal_state.md"
    if (Test-Path $stateFile) {
        $text = Get-Content $stateFile -Raw -Encoding UTF8
        if ($text -match "current_version\s*:\s*(\S+)") {
            $Version = $Matches[1].Trim()
        }
    }
}
if (-not $Version) { $Version = "dev" }

$time = Get-Date -Format "yyyyMMdd_HHmmss"
$zipName = "study_agent_release_$Version`_$time.zip"
$OutputZip = Join-Path $Root "$OutputDir\$zipName"
$OutDir = Split-Path $OutputZip -Parent
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }

Write-Host "Root: $Root"
Write-Host "Version: $Version"
Write-Host "Output: $OutputZip"

$pyFile = Join-Path $env:TEMP "study_agent_pack.py"
$includeTestsFlag = if ($IncludeTests) { "1" } else { "0" }

@'
import zipfile, pathlib, sys

root = pathlib.Path(sys.argv[1])
dest = pathlib.Path(sys.argv[2])
dest.parent.mkdir(parents=True, exist_ok=True)
include_tests = sys.argv[3] == "1"

EXCLUDE_DIRS = {
    "__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache",
    ".git", ".github", ".vscode", ".idea",
    "venv", ".venv", "env", "node_modules",
    "logs", "backups", "release", "dist", "build",
}
EXCLUDE_KEYWORDS = ["visual_assets_pack"]

def _has_cjk(part):
    for ch in part:
        cp = ord(ch)
        if 0x4e00 <= cp <= 0x9fff:
            return True
        if 0x3400 <= cp <= 0x4dbf:
            return True
    return False

def should_exclude(rel):
    posix = rel.as_posix()
    parts = rel.parts
    if parts[0] in EXCLUDE_DIRS:
        return True
    for kw in EXCLUDE_KEYWORDS:
        if kw in posix:
            return True
    if rel.suffix in (".pyc", ".pyo", ".bak"):
        return True
    if rel.name == ".env":
        return True
    if rel.name.endswith(".zip"):
        return True
    if not include_tests and parts[0] == "tests":
        return True
    for p in parts:
        if p in EXCLUDE_DIRS:
            return True
        if _has_cjk(p):
            return True
    return False

with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
    count = 0
    for f in sorted(root.rglob("*")):
        if not f.is_file():
            continue
        rel = f.relative_to(root)
        if should_exclude(rel):
            continue
        entry = rel.as_posix()
        zf.write(f, entry)
        count += 1

names = zf.namelist()
for path in names:
    if "\\" in path:
        print("ERROR: backslash path:", path, file=sys.stderr)
        sys.exit(1)
    if path == ".env" or path.endswith("/.env"):
        print("ERROR: .env in zip:", path, file=sys.stderr)
        sys.exit(1)

required = ["app.py", "requirements.txt", ".env.example", "src/wechat.py"]
missing = [r for r in required if r not in names]
if missing:
    print("ERROR: missing:", missing, file=sys.stderr)
    sys.exit(1)

print("OK:", count, "files, forward-slash verified")
'@ | Set-Content -LiteralPath $pyFile -Encoding UTF8

$result = python $pyFile $Root $OutputZip $includeTestsFlag 2>&1
Remove-Item -LiteralPath $pyFile -Force -ErrorAction SilentlyContinue
if ($LASTEXITCODE -ne 0) {
    Write-Error $result
    exit 1
}
Write-Host $result
$sizeMB = [Math]::Round((Get-Item $OutputZip).Length / 1MB, 2)
Write-Host "Done: $OutputZip ($sizeMB MB)"
