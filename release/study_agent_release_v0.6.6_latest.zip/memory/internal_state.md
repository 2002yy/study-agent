# 内部状态

## 当前运行模式
- memory_mode: preview
- route_mode: auto_rule
- debug_mode: false
- safe_mode: false
- performance_mode: fast
- entry_mode: wechat

## 当前阶段
- current_version: v0.6.6
- active_task: 展示身份安全、safe_writer 临时文件隔离、打包守护测试收口
- next_version: v0.6.7

## 规则边界
- 不自动污染长期记忆。
- 不绕过用户确认写入。
- 不让群聊替代正式学习。
- 不让互动氛围削弱纠错和任务边界。
- safe_mode=true 时禁止写入长期记忆。
