# README_internal_modes.md

## 1. 内部模式是什么

内部模式用于控制 Agent 在不同场景下的行为，不是隐藏剧情，而是状态管理系统。

## 2. 当前内部模式

| 字段 | 说明 | 可选值 |
|------|------|--------|
| relationship_mode | 互动氛围 | standard / warm / close |
| wechat_mode | 微信群状态 | unread_feedback / first_user_join / interactive_group |
| memory_mode | 记忆读写权限 | readonly / preview / confirm_write / locked |
| route_mode | 自动路由模式 | manual / auto_rule / locked_route |
| debug_mode | 调试信息显示 | true / false |
| safe_mode | 安全模式（禁止写入） | true / false |

## 3. 状态文件

| 文件 | 存储内容 |
|------|----------|
| `memory/internal_state.md` | memory_mode / route_mode / debug_mode / safe_mode |
| `memory/interaction_settings.md` | relationship_mode |
| `chat/wechat_state.md` | wechat_mode / user_has_joined / memory_capture 状态 |

## 4. 模式说明

### relationship_mode
- **standard**：标准学习伙伴语气
- **warm**：更温和鼓励，有陪伴感，不进入恋爱感扮演
- **close**：恋爱感陪伴，更强陪伴感/温柔感/在意感。但禁止成人内容、不模拟现实恋人、不削弱教学边界

### wechat_mode
- **unread_feedback**：课后反馈区，角色不知用户可看到
- **first_user_join**：用户首次在群聊发言，触发四人惊讶反应
- **interactive_group**：互动群聊，正常回复

### memory_mode
- **readonly**：只读，不可写入
- **preview**：可生成预览/候选，不可正式写入
- **confirm_write**：用户确认后允许写入
- **locked**：完全锁定，不读写

### route_mode
- **manual**：手动选择
- **auto_rule**：关键字匹配自动路由
- **locked_route**：锁定当前路由结果

## 5. 安全边界

- `safe_mode=true` 时禁止写入长期记忆
- `memory_mode=preview` 时只能生成候选，不能正式写入
- `close` 只增强陪伴感，不生成成人内容，不削弱学习目标
- 所有写入必须走 `safe_writer.py`（备份 → 临时文件 → 替换）

## 6. 验收测试

```
python -m src.mode_manager
```
预期：
```
relationship_mode: standard
wechat_mode: unread_feedback
memory_mode: preview
route_mode: auto_rule
safe_mode: false
```

### 测试 1：读取内部状态 ✓
`python -m src.mode_manager` → 5 项全部正确

### 测试 2：切换互动氛围 ✓
侧栏选择"亲近陪伴 warm" → `memory/interaction_settings.md` 写入 `relationship_mode: warm`

### 测试 3：close 边界
选择"恋爱感陪伴 close"，输入"用流萤的语气帮我复盘一下今天进度。"
预期：更温柔、更有陪伴感，仍围绕复盘，不生成成人内容，不模拟现实恋人身份，不削弱任务边界

### 测试 4：微信群第一次入群
`user_has_joined_group=false`，用户在微信群输入"我看得到你们在说什么。"
预期：四人短暂惊讶，`wechat_state.md` 更新 `user_has_joined_group=true`、`first_join_reaction_done=true`、`mode=interactive_group`

### 测试 5：第二次入群不再惊讶
用户再次输入"那你们继续说，我看看。"
预期：正常群聊互动，不重复惊讶

### 测试 6：关闭微信群记忆提取 ✓
`memory_capture_enabled=false`，点击"提取记忆候选"
预期：不生成 candidates，不写入 memory

### 测试 7：safe_mode 禁止写入 ✓
`safe_mode=true`，尝试"确认写入长期记忆"
预期：阻止写入，提示安全模式，memory 文件不变
