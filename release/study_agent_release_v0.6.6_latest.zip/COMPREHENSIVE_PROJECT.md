# 个人学习 Agent — 项目全貌

> 本文档供无上下文的 AI 或新开发者快速理解整个项目。

## 1. 项目定义

一个 **Python + Streamlit** 学习管理 Agent 系统，核心体验：
- 把知识拆成对话流，用苏格拉底/费曼模式引导思考
- 四人角色化教学（三月七/刻晴/纳西妲/流萤），各有教学风格和禁止边界
- Markdown 文件作为长期记忆，保证跨会话连续性
- 微信群未读机制增强启动动力
- 课后更新：对话结束 → 生成五类文件更新 → 预览 → 确认 → 安全写入

## 2. 技术栈

| 层 | 选择 |
|---|---|
| 语言 | Python 3.12+ |
| UI | Streamlit |
| LLM | OpenAI-compatible SDK（不绑定厂商） |
| 存储 | Markdown 文件（不引入数据库） |
| 配置 | .env |
| 测试 | pytest（19 条） |

## 3. 项目结构

```
study_agent/
├── app.py                    # Streamlit 入口，40 行
├── .env / .env.example
├── requirements.txt          # streamlit openai python-dotenv pyyaml pytest python-docx
├── PROJECT_PLAN.md           # 版本路线图
├── USER_GUIDE.md             # 用户指南
├── FUTURE.md                 # 未来方向
├── COMPREHENSIVE_PROJECT.md  # 本文件
│
├── src/
│   ├── llm_client.py         # API 封装（chat + chat_stream 双模式）
│   ├── router.py             # 关键字匹配路由 + LLM Router 低置信度兜底
│   ├── llm_router.py         # LLM 兜底路由（仅规则低置信度时调用）
│   ├── context_builder.py    # 拼装 LLM 上下文（prompt + 记忆 + 模式 + 氛围）
│   ├── role_manager.py       # 读取 roles/*.md 角色人设
│   ├── memory.py             # 读取 memory/ 下所有 md 文件
│   ├── memory_writer.py      # 长期记忆写入统一入口（调用 safe_writer + 权限检查）
│   ├── memory_tools.py       # 记忆搜索/编辑/diff/回滚/清理/归档
│   ├── safe_writer.py        # 原子写入（备份 → .tmp → replace → 出错恢复）
│   ├── after_session.py      # 课后更新生成器（JSON 解析 + role_updates）
│   ├── wechat.py             # 群聊生成/读取/存储/搜索/摘要/互动回复
│   ├── wechat_memory.py      # 群聊内容 → 长期记忆候选提取
│   ├── session_logger.py     # 日志（session 归档 + current_session 自动保存）
│   ├── session_store.py      # SessionMeta dataclass（替代模块级全局变量）
│   ├── model_stats.py        # 模型使用统计（Flash/Pro/Router 调用 + 耗时 + 成本）
│   ├── config.py             # 配置前置校验
│   ├── health_check.py       # 32 项系统健康检查
│   ├── backup_manager.py     # 备份列表/恢复
│   ├── update_validator.py   # 课后更新质量检查（情绪推断/过长/超前声称）
│   ├── export_tools.py       # 导出（Markdown/docx/群聊/项目状态）
│   └── mode_manager.py       # 运行时模式管理（internal_state/interaction/wechat_state）
│
├── src/ui/                   # UI 面板（5 个）
│   ├── session_state.py      # st.session_state 初始化 + 刷新
│   ├── sidebar.py            # 侧栏（角色/模式/模型/路由调试/记忆/微信群/氛围/内部模式/导出）
│   ├── chat_panel.py         # 主聊天区（历史 + 输入 + 路由 + API + 日志）
│   ├── after_session_panel.py# 课后更新预览 + 确认写入 + 群聊反馈
│   ├── wechat_panel.py       # 微信群显示 + 互动 + 记忆提取
│   ├── theme.py              # 全局 CSS（Catppuccin 暗色主题）
│   ├── status_bar.py         # 状态条 + 模型统计行
│   ├── avatar.py             # 头像（图片优先 + 文字 fallback）
│   └── wechat_bubble.py      # 气泡渲染（纯 HTML 组件）
│
├── memory/                   # 长期记忆状态文件
│   ├── summary.md            # P1 压缩摘要（优先读）
│   ├── current_focus.md      # P1 当前焦点（优先/暂缓/禁止）
│   ├── learner_profile.md    # P2 学习者档案 + 待确认区
│   ├── progress.md           # P3 学习进度
│   ├── project_context.md    # P3 项目上下文
│   ├── agent.md              # Agent 说明
│   ├── system_detail.md      # 系统架构
│   ├── task_board.md         # 任务看板（Sprint/验收/版本记录）
│   ├── internal_state.md     # 内部模式（唯一事实源）
│   ├── interaction_settings.md # 互动氛围设置
│   └── pending_updates/      # 待确认的更新候选
│
├── roles/                    # 角色人设（9 段结构，~1100 字/角色）
│   ├── march7.md             # 学习启动器
│   ├── keqing.md             # 任务收束器
│   ├── nahida.md             # 概念结构化器
│   └── firefly.md            # 收束后的陪伴者
│
├── chat/                     # 微信群相关
│   ├── wechat_group.md       # 完整群聊存档
│   ├── wechat_unread.md      # 未读消息缓存
│   └── wechat_state.md       # 群聊可见性/入群/记忆提取状态
│
├── logs/
│   ├── current_session.md    # 当前会话临时保存（每次消息自动写入）
│   ├── session_archive.md    # 归档
│   ├── revision_notes.md     # 修订笔记
│   └── sessions/             # 按日期归档的 session 日志
│
├── templates/
│   ├── wechat_update.md      # 群聊生成 prompt
│   ├── wechat_interactive_reply.md # 群聊互动回复 prompt
│   ├── wechat_memory_extract.md   # 群聊记忆提取 prompt
│   └── routing_rules.md      # 路由规则（备用 Markdown 格式）
│
├── config/
│   └── routing_rules.yaml    # 路由规则（YAML，优先读取）
│
├── assets/                   # 视觉资源（16 个图片文件）
│   ├── avatars/ (4 pngs)
│   ├── avatars_alt/ (4 pngs)
│   ├── backgrounds/ (4 jpgs)
│   └── banners/ (4 jpgs)
│
├── backups/memory_backups/   # 写入前自动备份
├── tests/                    # 18 个 pytest 测试
├── tools/package_project.ps1 # 打包脚本
└── exports/                  # 导出的报告（自动创建）
```

## 4. 核心架构

### 总控模式

```
app.py
  → session_state 初始化
  → 渲染 4 个 UI Panel
    → sidebar: 设置/记忆/微信群/氛围/内部模式/导出
    → chat_panel: 用户输入 → router → context_builder → API → 日志
    → after_session_panel: 预览 → 确认写入 → 群聊反馈
    → wechat_panel: 显示 → 互动 → 记忆提取
```

### 路由优先级

```
用户手动锁定 → route_lock → 规则 high/medium → 规则 low → LLM Router → 默认
```

### 写入权限

```
sidebar 确认按钮 → mode_manager.is_memory_write_allowed()
  → safe_mode / locked / readonly → 阻止
  → preview → run_with_confirm_write(临时切换到 confirm_write)
  → memory_writer → safe_writer → 文件
```

### 课后更新流程

```
对话 → 生成预览 → 5 类更新 + role_updates → 分项勾选 → 确认写入
  → safe_writer (备份 → .tmp → replace)
  → 角色动态记录写入 roles/*.md
  → 生成微信群反馈
```

### 微信群流程

```
课后更新 → 生成群聊反馈 → 写入 wechat_unread.md + wechat_group.md
  → 用户查看 → 首次发言惊讶 → 互动群聊
  → 记忆候选提取 → 用户确认写入
```

## 5. 角色体系

| 角色 | 核心定位 | 触发场景 | 禁止 |
|------|----------|----------|------|
| 三月七 | 学习启动器 | 开场、入门、轻互动 | 不能只卖萌、不能娱乐化严肃任务 |
| 刻晴 | 任务收束器 | 项目、代码、边界模糊 | 不能只训话、不能压成纯待办 |
| 纳西妲 | 概念结构化器 | 本质、机制、概念关系 | 不能空泛玄学、不能只给比喻 |
| 流萤 | 陪伴者 | 复盘、收尾、情绪承接 | 不能替代教学、不能只说空话 |

每个角色文件含 9 段：核心定位 → 性格层次 → 教学风格 → 项目推进 → 论文修改 → 微信群风格 → 互动方式 → 禁止跑偏 → 动态记录区

## 6. 模式系统

### 教学模式（7 种）
普通 / 苏格拉底追问链 / 费曼评分 / 项目推进 / 论文修改 / 概念地图

### 互动氛围（3 档）
standard（标准）/ warm（亲近陪伴）/ close（恋爱感陪伴）

### 内部模式
- memory_mode: preview / confirm_write / readonly / locked
- route_mode: auto_rule / manual
- safe_mode: 禁止写入
- debug_mode: 显示 RuntimeModes

## 7. 当前版本状态

v0.5.3 — 功能完成，视觉模块拆分完成。

- 32 健康检查全通过
- 19 条 pytest 测试全通过
- 所有写入走 safe_writer（备份 + 原子写入）
- LLM Router 仅用于规则低置信度兜底
- 视觉使用 Catppuccin 暗色主题 + 图片头像 + 文字 fallback

## 8. 如何使用

```powershell
pip install -r requirements.txt
Copy-Item .env.example .env  # 编辑填入 API key
streamlit run app.py
```

浏览器打开 `http://localhost:8501`。侧栏全部选"自动"即可使用。
