# 用户指南

## 1. 如何启动

```powershell
# 进入项目目录
cd "C:\Users\96967\Desktop\study agent"

# 安装依赖（仅首次）
pip install -r requirements.txt

# 复制配置文件并填入 API key
Copy-Item .env.example .env
# 编辑 .env，填入真实值：
#   OPENAI_API_KEY=your_api_key_here
#   OPENAI_BASE_URL=https://api.deepseek.com
#   MODEL_FLASH_NAME=deepseek-chat
#   MODEL_PRO_NAME=deepseek-chat

# 启动
streamlit run app.py
```

浏览器打开 `http://localhost:8501`。

## 2. 如何配置 API

编辑 `.env`：

```
OPENAI_API_KEY=your_api_key_here
OPENAI_BASE_URL=https://api.deepseek.com
MODEL_FLASH_NAME=deepseek-chat
MODEL_PRO_NAME=deepseek-chat
DEFAULT_MODEL_PROFILE=flash
```

- `MODEL_FLASH_NAME`：快速/便宜模型，用于日常问答和群聊
- `MODEL_PRO_NAME`：深度/复杂模型，用于课后更新和论文修改
- 两个模型可以填同一个名字

启动后页面顶部会自动检查配置，缺失项给出明确提示。

## 3. 如何选择角色/模式/模型

侧栏 **设置**：

| 控件 | 选项 | 说明 |
|------|------|------|
| 角色 | 自动 / 三月七 / 刻晴 / 纳西妲 / 流萤 | 选"自动"由系统判断 |
| 模式 | 自动 / 普通 / 苏格拉底 / 费曼 / 项目 / 论文 / 概念地图 | 苏格拉底=追问、费曼=评分、项目=任务管理 |
| 模型 | 自动 / Flash / Pro | Flash 快速便宜、Pro 深度复杂 |

推荐全部"自动"，系统会根据你的输入智能选择。

**路由调试面板**显示每次判断的依据、置信度、命中关键词。勾选"本轮锁定"后不再自动切换。

## 4. 如何使用微信群

### 完整流程

1. 完成一轮学习对话
2. 点击侧栏 **生成课后更新预览**
3. 查看五类更新建议，勾选需要的
4. 点击 **确认写入长期记忆**
5. 选择群聊风格（简短/标准/稍微有温度）
6. 点击 **生成微信群反馈**

### 群聊互动

- 侧栏 **查看未读消息** — 查看四人课后反馈
- 主区输入框 **在群里说一句** — 参与群聊
- 第一次发言四人会短暂惊讶（每轮群聊只一次）
- 后续正常互动，可引用消息为记忆候选

### 群聊工具

- **搜索群聊** — 关键词跨历史搜索
- **生成群聊摘要** — 查看最近群聊摘要
- **引用为记忆候选** — 每条消息旁有引用按钮

## 5. 如何生成课后更新

1. 正常对话后，点击侧栏 **生成课后更新预览**
2. 页面展示五类更新建议：
   - progress.md — 学习进度
   - learner_profile.md — 学习者档案
   - current_focus.md — 当前焦点
   - revision_notes.md — 修订笔记
   - session_archive.md — 本轮归档
3. 每项可单独勾选/取消
4. current_focus 会展示新旧对比
5. 点击 **确认写入长期记忆**

所有写入前自动备份到 `backups/memory_backups/`。可以在侧栏"记忆工具"中回滚。

## 6. 如何管理长期记忆

侧栏 **当前记忆状态** 展示 progress/current_focus/learner_profile 前 6 行。

**记忆工具**（展开）：

| 功能 | 操作 |
|------|------|
| 搜索 | 输入关键词，跨 7 个 memory 文件搜索 |
| 编辑 | 下拉选文件，直接编辑文本，保存 |
| 查看 diff | 比较当前文件与最近备份的差异 |
| 回滚 | 一键恢复最近备份 |
| 清理进度 | 截断 progress.md 至最近 50 行 |
| 归档进度 | 移至 `memory/archives/` |

**安全模式**：侧栏内部模式勾选"安全模式"后，禁止所有长期记忆写入。适合测试或担心误写时使用。

## 7. 如何导出报告

侧栏底部 **导出数据**：

| 按钮 | 输出 |
|------|------|
| 导出学习报告 | `exports/session_report_*.md` |
| 导出 docx | `exports/session_report_*.docx` |
| 导出项目状态 | `exports/project_status_*.md` |
| 导出群聊记录 | `exports/wechat_records_*.md` |
| 导出 session 归档 | `exports/session_archive_*.md` |

docx 导出需要 `pip install python-docx`。

## 8. 如何查看模型使用统计

页面标题下方状态栏第二行显示：

```
Flash: 3 | Pro: 2 | 上次耗时: 2.3s | 估算成本: ¥0.0012
```

统计包括 Flash/Pro 各调用次数、上次响应耗时、累计成本估算。耗时超过 8 秒显示 ⚠️ 慢标记。

成本估算基于 Flash=1元/M tokens、Pro=2元/M tokens，仅供参考。

## 9. 如何安全打包

```powershell
.\tools\package_project.ps1
```

生成 `study_agent_release.zip`，自动排除：
- `.env`（密钥） + `__pycache__` + 备份 + 日志
- 保留 `.env.example`

如果 zip 中误含 `.env`，脚本会报错并删除 zip。

## 10. 常见问题

**Q: 启动后页面显示"配置未完成"？**
A: `.env` 中 API key 或模型名未填写。复制 `.env.example` 为 `.env` 并填入真实值。

**Q: 回答很慢？**
A: 模型默认 Flash，可切换到 Pro 获得更深回答。也可在侧栏查看"上次耗时"。

**Q: 角色回复串味了？**
A: 侧栏切换角色后上下文会重置。也可勾选"本轮锁定"保持同角色。

**Q: 写入文件后后悔了？**
A: 侧栏 → 记忆工具 → 查看 diff → 回滚最近备份。

**Q: 切换到安全模式有什么用？**
A: 禁止所有长期记忆写入，适合测试新功能或担心误写时使用。

**Q: 群聊消息不见了？**
A: 点击"结束本轮并保存日志"会清空群聊显示，但 `chat/wechat_group.md` 保留完整历史。

**Q: 想恢复更早的备份？**
A: `python -m src.backup_manager` 列出所有备份。`python -m src.backup_manager restore <文件名>` 恢复指定备份。

**Q: 如何运行测试？**
A: `python -m pytest tests/ -v`（19 条测试）。
