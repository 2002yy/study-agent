# Study Agent — 项目规划契约

> 本文档为项目级决策记录。凡写入本文件的结论，非经再次讨论不得单方面变更。
> 最后更新：2026-05-06（v0.1–v0.7 路线确定）

---

## 一、项目定义

一个 **学习管理型 Agent 系统**，核心体验是：
- 把知识拆成对话流，用苏格拉底/费曼模式引导思考
- 四人角色化表达层提供教学节奏、情绪反馈、陪伴感
- Markdown 文件作为长期记忆，保证跨会话连续性
- 微信群未读机制增强启动动力和粘性

v1 定位：**通用学习助手**。后期可扩展陪伴强度开关。

---

## 二、架构决策

### 2.1 Agent 架构

v1 采用 **单总控 Orchestrator + 多角色适配器**，不做自治多Agent。

```
总控 Orchestrator
  ├─ context_builder    # 拼装 LLM 上下文
  ├─ mode_router        # 判断教学/项目/论文/复盘/群聊
  ├─ role_manager       # 根据场景选择出场角色
  ├─ llm_client         # 调用 LLM 生成回复
  ├─ wechat             # 群聊生成与读取
  └─ after_session      # 课后更新生成器
```

角色差异由以下三层体现：
1. role prompt（静态人设文件）
2. 角色动态记录（learner_profile 中角色视角的观察）
3. 场景路由（User状态 → 选择合适角色出场）

所有角色共享 `session_summary`，不维护独立全量历史。群聊采用**串行生成**：同一份摘要分别交给四个角色生成，再拼接写入 `wechat_unread.md`。

### 2.2 技术栈

| 层 | 选择 |
|---|---|
| 语言 | Python |
| UI | Streamlit |
| LLM | OpenAI-compatible SDK，不绑定具体模型 |
| 存储 | Markdown 文件（不引入数据库） |
| 配置 | .env |

### 2.3 课后更新机制（系统核心）

触发条件：用户说"下课/结束/收尾/复盘/生成课后更新"或主动点击按钮。

流程：
1. 总结本轮 session
2. 生成 `progress.md` 更新建议
3. 生成 `learner_profile.md` 更新建议
4. 生成 `current_focus.md` 更新建议
5. 生成 `revision_notes.md` 更新建议
6. 生成 `session_archive.md` 归档
7. 生成 `wechat_unread.md` 群聊反馈
8. **必须先预览，用户确认后再写入**
9. **写入前自动备份旧版本至 `backups/memory_backups/`**

---

## 四、版本路线

先骨架，再智能；先记忆，再角色；先课后更新，再微信群；先功能稳定，再视觉沉浸。

### v0.1 · 能跑起来

**已完成 ✓**

- [x] Streamlit 聊天界面
- [x] LLM API 调用
- [x] 读取角色文件
- [x] 手动选择角色（三月七 / 刻晴 / 纳西妲 / 流萤）
- [x] 手动选择模式（苏格拉底 / 费曼 / 项目 / 论文）
- [x] 保存本轮聊天日志到 `logs/sessions/`

### v0.2 · 长期记忆

**已完成 ✓**

- [x] Markdown 状态文件读取
- [x] `context_builder.py` 上下文拼装
- [x] 回复中体现当前学习状态（进度、薄弱点、当前重点）
- [x] `session_archive.md` 归档

### v0.3 · 课后更新

**已完成 ✓**

- [x] `progress.md` 更新生成
- [x] `learner_profile.md` 更新生成
- [x] `current_focus.md` 更新生成
- [x] `revision_notes.md` 更新生成
- [x] `session_archive.md` 自动生成
- [x] `safe_writer.py` 安全写入（备份 → 临时文件 → 替换 → 出错恢复）
- [x] 写入前自动备份至 `backups/memory_backups/`

### v0.4 · 微信群机制

**已完成 ✓**

- [x] 四人群聊生成（同一份 session_summary 分别调用四个角色）
- [x] 写入 `wechat_unread.md`
- [x] 未读/已读机制
- [x] 群聊追加到 `wechat_group.md`
- [x] 清空 `wechat_unread.md`

### v0.5 · 自动模式路由 + 自动角色调度

**已完成 ✓**

- [x] `router.py` 自动判断
- [x] `role_manager.py` 自动调度
- [x] 手动选择仍保留作为覆盖选项

### v0.5.1 · 稳定性回补

**已完成 ✓**

- [x] 系统健康检查（32项）
- [x] 配置前置校验
- [x] 流式输出
- [x] 当前会话临时保存
- [x] 课后更新分项确认
- [x] current_focus 写入前对比
- [x] learner_profile 待确认机制
- [x] 路由置信度与命中关键词
- [x] memory summary 压缩层
- [x] 微信群长度限制与状态头

### v0.5.2 · 角色深度 + 微信群互动

**已完成 ✓**

- [x] 角色文件 170→1000+ 字升级（9段结构）
- [x] 微信群用户参与聊天
- [x] 首次入群惊讶反应（每轮群聊重置）

### v0.5.3 · 微信群记忆提取 + 互动氛围

**已完成 ✓**

- [x] 微信群内容提取长期记忆候选
- [x] 互动氛围 standard / warm / close
- [x] close 恋爱感陪伴（禁止成人内容，不模拟现实恋人）
- [x] 内部模式系统（internal_state / interaction_settings / wechat_state）
- [x] RuntimeModes + mode_manager 全局接入

### v0.5.4 · 工程收束

**进行中**

- [x] 修复 is_memory_write_allowed preview bug
- [x] run_with_confirm_write 上下文管理器
- [x] 写入权限分层收口（memory_writer）
- [x] 状态文件同步（memory/ wechat_state/ PROJECT_PLAN）
- [x] app.py 655→26 行拆分（src/ui/）
- [x] pytest 测试体系标准化（19 tests）
- [ ] 回归测试

### v0.6 · 视觉增强

**目标**：头像、背景、气泡、未读标记，让系统不再是冷冰冰的聊天框。

- [ ] 角色头像绑定
- [ ] 聊天/群聊背景
- [ ] 消息气泡样式
- [ ] 未读红点/提示
- [ ] 角色状态条（当前主讲、今日重点等）
- [ ] 群聊卡片风格

### v0.7 · 陪伴强度开关

**已提前完成** — standard / warm / close 三档已在 v0.5.3 实现，通过 `memory/interaction_settings.md` 控制。

---

## 五、角色职责与行为边界

| 角色 | 职责 | 禁止 |
|------|------|------|
| 三月七 | 学习启动器，把问题变有趣 | 不能过度打断、不能把复杂问题娱乐化 |
| 刻晴 | 任务收束器，防止跑题和失控 | 不能变成单纯训话、不能只训不建 |
| 纳西妲 | 本质提炼者，建概念地图 | 不能空泛玄学、不能只给比喻不给落脚点 |
| 流萤 | 课后陪伴者，承接情绪与复盘余韵 | 不能替代正式教学、温柔但不能只说空话、不能拖重学习气氛 |

### 出场节奏（默认建议，非强制）

1. 三月七开场 → 2. 刻晴压住边界 → 3. 纳西妲提炼本质 → 4. 流萤收住余温

---

## 六、关键行为约束（全局）

- 输出风格：深层拆解、具体可执行、可直写文档/代码
- 群聊：不跑题闲扯、不替用户编造感受、不过度夸赞、角色间观点可以不同但不陷入争吵
- 角色一致：不串味、不越界
- 状态文件：不自动覆盖，预览确认后才写入
