from __future__ import annotations

import hashlib
import html as html_mod
import re

import streamlit as st

from src.mode_manager import load_runtime_modes, run_with_confirm_write, update_wechat_join_state
from src.session_logger import (
    set_wechat_interactive,
    set_wechat_memory_candidates,
    set_wechat_status,
    set_wechat_unread_cleared,
)
from src.ui.wechat_bubble import format_wechat_bubbles
from src.wechat import (
    append_interactive_group_reply,
    append_user_group_message,
    count_wechat_messages,
    ensure_wechat_group_bootstrapped,
    generate_interactive_wechat_reply_stream,
    has_wechat_unread,
    mark_wechat_read,
    normalize_interactive_wechat_reply,
    read_wechat_group,
    read_wechat_state,
    read_wechat_unread,
    reset_wechat_group,
    search_wechat,
    summarize_wechat,
)
from src.wechat_memory import (
    append_manual_memory_candidate,
    apply_candidate_to_memory,
    extract_memory_candidates,
    save_candidates,
)


def _active_wechat_content() -> tuple[str, str]:
    if st.session_state.get("wechat_messages"):
        return st.session_state.wechat_messages, "thread"

    group = read_wechat_group()
    unread = read_wechat_unread()
    state = read_wechat_state()

    if state["mode"] == "interactive_group" and group:
        return group, "thread"
    if has_wechat_unread():
        return unread, "unread"
    return group, "thread"


def _render_wechat_stream(target, content: str):
    if content and any(name in content for name in ["【三月七】", "【刻晴】", "【纳西妲】", "【流萤】", "【用户】"]):
        target.markdown(format_wechat_bubbles(content), unsafe_allow_html=True)
        return
    if content:
        target.markdown(content)
        return
    target.info("当前还没有新的群聊内容。只有当你点击按钮或发送消息时，才会触发群聊互动。")


def _render_wechat_tools(content: str):
    with st.expander("群聊工具", expanded=False):
        st.caption(f"当前可见消息数：{count_wechat_messages(content)}")
        keyword = st.text_input("搜索群聊", key="wc_search", placeholder="输入关键词...")
        if keyword:
            results = search_wechat(keyword)
            for item in results[:5]:
                st.caption(f"**{item['speaker']}**")
                st.text(item["text"][:100])

        if st.button("生成群聊摘要", key="wechat_summary"):
            st.text(summarize_wechat())


def _render_wechat_memory_actions(content: str):
    if not st.session_state.get("wechat_memory_enabled"):
        return

    if st.button("提取微信群记忆候选", key="extract_wechat_memory"):
        with st.spinner("正在提取记忆候选..."):
            candidates = extract_memory_candidates(
                wechat_content=content,
                memory_bundle=st.session_state.memory_bundle,
            )
        has_any = any(candidates.get(k) for k in candidates)
        if has_any:
            save_candidates(candidates)
            set_wechat_memory_candidates(st.session_state.session_id, "generated")
            st.success("记忆候选已提取")
            st.session_state.wechat_memory_candidates = candidates
        else:
            st.warning("未提取到候选内容")

    if st.session_state.get("wechat_memory_candidates"):
        with st.expander("记忆候选", expanded=False):
            candidates = st.session_state.wechat_memory_candidates
            for key in [
                "summary_candidates",
                "progress_candidates",
                "current_focus_candidates",
                "learner_profile_candidates",
                "revision_notes_candidates",
                "session_archive_candidates",
            ]:
                items = candidates.get(key, [])
                if not items:
                    continue
                st.caption(f"**{key}** ({len(items)} 条)")
                for idx, item in enumerate(items):
                    st.text(f"[{idx}] {item.get('content', '')[:80]}")
                    if st.button(f"确认写入 {key}[{idx}]", key=f"apply_{key}_{idx}"):
                        modes = load_runtime_modes()
                        if modes.safe_mode:
                            st.warning("当前为安全模式，禁止写入长期记忆。")
                        elif modes.memory_mode == "locked":
                            st.warning("长期记忆已锁定，禁止写入。")
                        else:
                            result = run_with_confirm_write(
                                lambda: apply_candidate_to_memory(
                                    key, idx, st.session_state.interaction_mode
                                )
                            )
                            if result:
                                st.success(f"已写入 {result}")
                            else:
                                st.warning("写入失败")


def _render_citation_tools(content: str):
    with st.expander("引用到记忆候选", expanded=False):
        blocks = re.findall(r"【(.+?)】\s*(.+?)(?=\n【|\Z)", content, re.DOTALL)
        if not blocks:
            st.caption("当前没有可引用的角色消息。")
            return
        cited_map = st.session_state.setdefault("wechat_cited_items", {})
        st.caption("把你觉得有长期价值的群聊片段一键加入候选。已加入的条目会在这里直接标记出来。")
        for idx, (speaker, msg) in enumerate(blocks):
            text = msg.strip()[:100]
            safe_speaker = html_mod.escape(speaker)
            safe_text = html_mod.escape(text)
            cite_key = hashlib.md5(f"{speaker}:{text}".encode("utf-8")).hexdigest()
            already_cited = bool(cited_map.get(cite_key))
            cols = st.columns([6, 2])
            with cols[0]:
                status_badge = (
                    '<span class="wechat-cite-badge added">已加入</span>'
                    if already_cited
                    else '<span class="wechat-cite-badge">可加入</span>'
                )
                st.markdown(
                    f"""
                    <div class="wechat-cite-row">
                        <div class="wechat-cite-meta">[{safe_speaker}]</div>
                        <div class="wechat-cite-text">{safe_text}...</div>
                        <div class="wechat-cite-status">{status_badge}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with cols[1]:
                if already_cited:
                    st.button("已加入", key=f"cite_done_{idx}", disabled=True, use_container_width=True)
                elif st.button("加入候选", key=f"cite_{idx}", use_container_width=True):
                    candidates = append_manual_memory_candidate(speaker, text)
                    cited_map[cite_key] = {
                        "speaker": speaker,
                        "text": text,
                    }
                    st.success(f"已将 [{speaker}] 这条消息加入记忆候选")
                    st.session_state.wechat_memory_candidates = candidates
                    st.rerun()


def _stream_pending_reply(content_placeholder):
    pending_input = st.session_state.get("wechat_pending_input")
    if not pending_input:
        return

    base_content = read_wechat_group()
    live_note = st.empty()
    live_note.caption("她们正在输入...")
    reply = ""

    try:
        stream_result = generate_interactive_wechat_reply_stream(
            pending_input,
            relationship_mode=st.session_state.interaction_mode,
        )
        for chunk in stream_result[0]:
            reply += chunk
            preview = base_content if not reply else base_content + "\n\n" + reply
            _render_wechat_stream(content_placeholder, preview)
    except Exception as exc:
        live_note.empty()
        st.session_state.wechat_pending_input = None
        st.error(str(exc))
        return

    live_note.empty()
    if reply.strip():
        reply = normalize_interactive_wechat_reply(reply)
        append_interactive_group_reply(reply)
        if stream_result[1]:
            update_wechat_join_state(
                user_has_joined=True,
                first_reaction_done=True,
                mode="interactive_group",
            )
        set_wechat_interactive(st.session_state.session_id, "generated")
    st.session_state.wechat_messages = read_wechat_group()
    st.session_state.wechat_pending_input = None
    st.rerun()


@st.fragment
def render_wechat_panel():
    ensure_wechat_group_bootstrapped()
    st.markdown("### 微信群聊天")
    state = read_wechat_state()
    content, source = _active_wechat_content()
    set_wechat_status(st.session_state.session_id, state["mode"])
    unread_count = count_wechat_messages(read_wechat_unread())

    top_cols = st.columns([2, 2, 2, 2])
    with top_cols[0]:
        st.caption(f"群聊状态：{state['mode']}")
    with top_cols[1]:
        st.caption(f"未读数量：{unread_count}")
    with top_cols[2]:
        st.caption(f"互动氛围：{st.session_state.interaction_mode}")
    with top_cols[3]:
        st.caption(f"当前视图：{'未读' if source == 'unread' else '完整线程'}")

    action_cols = st.columns([1, 1, 1])
    with action_cols[0]:
        if st.button("刷新群聊", key="refresh_wechat_view", use_container_width=True):
            st.session_state.wechat_messages = None
            st.rerun()
    with action_cols[1]:
        if st.button("标记已读", key="mark_wechat_read", use_container_width=True):
            mark_wechat_read()
            set_wechat_unread_cleared(st.session_state.session_id)
            st.session_state.wechat_messages = read_wechat_group()
            st.success("当前未读已标记为已读。")
            st.rerun()
    with action_cols[2]:
        if st.button("新群聊", key="new_wechat_group", use_container_width=True):
            reset_wechat_group()
            st.session_state.wechat_messages = None
            st.session_state.wechat_pending_input = None
            st.success("已开启新群聊。")
            st.rerun()

    content_placeholder = st.empty()
    _render_wechat_stream(content_placeholder, content)

    if content:
        _render_citation_tools(content)
        _render_wechat_tools(content)
        _render_wechat_memory_actions(content)

    with st.form("wechat_input_form", clear_on_submit=True):
        wechat_user_input = st.text_input(
            "在群里说一句",
            key="wechat_input",
            placeholder="在群里说一句...",
            label_visibility="collapsed",
        )
        send_wechat = st.form_submit_button("发送", use_container_width=True)

    if send_wechat and wechat_user_input and wechat_user_input.strip():
        user_text = wechat_user_input.strip()
        append_user_group_message(user_text)
        st.session_state.wechat_messages = read_wechat_group()
        st.session_state.wechat_pending_input = user_text
        st.rerun()

    _stream_pending_reply(content_placeholder)
