from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from src.llm_client import ModelProfile, chat, stream_chat
from src.mode_manager import load_runtime_modes, update_wechat_join_state
from src.safe_writer import append_text_safely, safe_write_text

ROOT = Path(__file__).resolve().parent.parent
GROUP_FILE = ROOT / "chat" / "wechat_group.md"
UNREAD_FILE = ROOT / "chat" / "wechat_unread.md"
STATE_FILE = ROOT / "chat" / "wechat_state.md"
ARCHIVE_DIR = ROOT / "chat" / "archive"
TEMPLATE_FILE = ROOT / "templates" / "wechat_update.md"
INTERACTIVE_TEMPLATE = ROOT / "templates" / "wechat_interactive_reply.md"

STYLE_PROMPTS = {
    "简短": "\n【风格要求】每条消息 1-2 句，每位不超过 60 字，总长度不超过 400 字。",
    "标准": "\n【风格要求】每条消息 2-3 句，每位不超过 100 字，总长度不超过 600 字。",
    "稍微有温度": "\n【风格要求】每条消息 2-4 句，每位不超过 120 字，总长度不超过 800 字。",
}

WECHAT_ROLE_ORDER = ["三月七", "刻晴", "纳西妲", "流萤"]
WECHAT_BLOCK_PATTERN = re.compile(r"【(.+?)】\s*(.+?)(?=\n【|\Z)", re.DOTALL)
WECHAT_BOOTSTRAP_TEXT = """【三月七】
今天这群安静得也太规矩了吧，我先来冒个泡。要是你正好看到，就把这里当成轻松一点的学习搭子小群也行。

【刻晴】
先说明白，这里不是分心区。更适合拿来快速同步进度、卡点和下一步安排，省得每次都重新整理。

【纳西妲】
我倒觉得这种形式很有意思。把零散的想法留在同一个线程里，之后回看时，往往更容易看出理解是怎么慢慢长出来的。

【流萤】
嗯，这样也挺好。累的时候来这里说一句今天做到哪儿了，或者只是留下一点心情，之后再继续往前走，也不会那么孤单。
"""
WECHAT_MISSING_ROLE_FALLBACKS = {
    "三月七": "我这边也接住啦，这句我听到了。那我先把气氛接上，我们继续往下聊。",
    "刻晴": "我补一句重点：先把你刚刚提到的核心问题记住，接下来按最关键的一步继续推进就好。",
    "纳西妲": "从这个角度看，你刚刚那句话其实已经给了线索。顺着它往下想，通常就能把眼前这一步理清一些。",
    "流萤": "我也在。别急，我们就顺着你刚刚这句话慢慢接下去，一点点把现在的感觉和事情放稳。",
}


def _load_text(path: Path, default: str = "") -> str:
    if not path.is_file():
        return default
    return path.read_text(encoding="utf-8").strip()


def _message_blocks(content: str) -> list[tuple[str, str]]:
    return [(speaker.strip(), text.strip()) for speaker, text in WECHAT_BLOCK_PATTERN.findall(content)]


def _format_role_blocks(blocks: list[tuple[str, str]]) -> str:
    return "\n\n".join(f"【{speaker}】\n{text.strip()}" for speaker, text in blocks if text.strip()).strip()


def _ensure_all_roles_reply(content: str) -> str:
    blocks = _message_blocks(content)
    if not blocks:
        return _format_role_blocks(
            [(speaker, WECHAT_MISSING_ROLE_FALLBACKS[speaker]) for speaker in WECHAT_ROLE_ORDER]
        )

    by_speaker: dict[str, list[str]] = {}
    for speaker, text in blocks:
        if speaker not in WECHAT_ROLE_ORDER:
            continue
        by_speaker.setdefault(speaker, []).append(text.strip())

    normalized_blocks: list[tuple[str, str]] = []
    for speaker in WECHAT_ROLE_ORDER:
        parts = [part for part in by_speaker.get(speaker, []) if part]
        if parts:
            normalized_blocks.append((speaker, "\n".join(parts)))
        else:
            normalized_blocks.append((speaker, WECHAT_MISSING_ROLE_FALLBACKS[speaker]))
    return _format_role_blocks(normalized_blocks)


def _load_system_prompt() -> str:
    return _load_text(
        TEMPLATE_FILE,
        "你是微信群聊生成器。根据本轮课后更新摘要，生成四位伙伴的群聊消息。输出格式：【角色名】\\n内容",
    )


def _load_interactive_prompt() -> str:
    return _load_text(
        INTERACTIVE_TEMPLATE,
        "你是微信群聊互动生成器。根据用户消息和群聊历史生成回复。输出格式：【角色名】\\n内容",
    )


def _build_interactive_messages(
    user_text: str,
    relationship_mode: str | None = None,
) -> tuple[list[dict], bool]:
    modes = load_runtime_modes()
    if relationship_mode is None:
        relationship_mode = modes.relationship_mode

    is_first = not modes.first_reaction_done
    prompt = _load_interactive_prompt()
    history = read_wechat_group()
    history_lines = history.splitlines()[-40:] if history else []

    if is_first:
        prompt += (
            "\n\n当前状态：这是这个群聊线程里用户第一次发言。"
            "请体现轻微惊讶和欢迎，但不要过度夸张。"
        )
    else:
        prompt += "\n\n当前状态：这不是第一次发言，请正常继续群聊互动。"

    if relationship_mode == "warm":
        prompt += "\n[互动氛围: warm] 更温和、更鼓励，但不进入恋爱感扮演。"
    elif relationship_mode == "close":
        prompt += (
            "\n[互动氛围: close] 可以更贴近更柔和，但不能生成成人内容，"
            "不能模拟现实恋人，不能削弱学习目标。"
        )

    messages = [
        {"role": "system", "content": prompt},
        {
            "role": "user",
            "content": "【最近群聊】\n"
            + "\n".join(history_lines)
            + f"\n\n【用户刚才说】\n{user_text}\n\n请生成群聊回复。",
        },
    ]
    return messages, is_first


def generate_wechat_messages(
    session_messages: list[dict],
    after_session_updates: dict[str, str],
    memory_bundle: dict[str, str],
    model_profile: ModelProfile = "flash",
    style: str = "标准",
    relationship_mode: str = "standard",
) -> str:
    if not after_session_updates:
        return ""

    context: list[str] = [_load_system_prompt() + STYLE_PROMPTS.get(style, STYLE_PROMPTS["标准"])]
    state = read_wechat_state()

    if relationship_mode == "warm":
        context.append(
            "\n[互动氛围: warm] 语气更温和、更鼓励，但仍然保持学习复盘导向。"
        )
    elif relationship_mode == "close":
        context.append(
            "\n[互动氛围: close] 可以更贴近、更温柔，但不能生成成人内容，不能模拟现实恋人，"
            "不能削弱学习目标。"
        )

    if state["user_has_joined"]:
        context.insert(0, "\n[系统说明] 用户已经在群聊里，可以直接对用户说话。")
    else:
        context.insert(0, "\n[系统说明] 当前更像课后反馈场景，不需要假定用户正在看。")

    update_keys = [
        ("session_archive_update", "本轮归档"),
        ("progress_update", "进度更新"),
        ("current_focus_update", "当前重点"),
    ]
    for key, label in update_keys:
        content = after_session_updates.get(key, "")
        if content and all(flag not in content for flag in ["失败", "无对话", "无需更新"]):
            context.append(f"\n【{label}】\n{content[:400]}")

    if memory_bundle.get("summary.md"):
        context.append(f"\n【现有摘要参考】\n{memory_bundle['summary.md'][:300]}")

    context.append("\n【最近对话背景】")
    for msg in session_messages[-2:]:
        speaker = "用户" if msg["role"] == "user" else "Agent"
        context.append(f"{speaker}: {msg['content'][:100]}")

    messages = [
        {"role": "system", "content": "\n".join(context)},
        {
            "role": "user",
            "content": f"请生成一版 {style} 风格的微信群消息，每位角色用【角色名】开头。",
        },
    ]
    raw = chat(messages, temperature=0.6, model_profile=model_profile).strip()
    return _ensure_all_roles_reply(raw)


def read_wechat_unread() -> str:
    return _load_text(UNREAD_FILE)


def read_wechat_group() -> str:
    return _load_text(GROUP_FILE)


def has_wechat_unread() -> bool:
    unread = read_wechat_unread()
    return bool(unread and "暂无未读消息" not in unread and "暂无未读" not in unread)


def ensure_wechat_group_bootstrapped() -> None:
    content = read_wechat_group()
    if _message_blocks(content):
        return
    safe_write_text(GROUP_FILE, WECHAT_BOOTSTRAP_TEXT.strip() + "\n")
    if not UNREAD_FILE.is_file():
        safe_write_text(UNREAD_FILE, "# 未读消息\n\n> 暂无未读消息。\n")
    update_wechat_join_state(
        user_has_joined=False,
        first_reaction_done=False,
        mode="interactive_group",
    )


def append_new_wechat_feedback(content: str) -> None:
    if not content.strip():
        return
    normalized = _ensure_all_roles_reply(content)

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    version = load_runtime_modes().current_version
    thread_id = uuid4().hex[:8]
    header = (
        "# 微信群未读消息\n\n"
        f"- 生成时间: {now}\n"
        "- 状态: unread\n"
        f"- 阶段: {version}\n"
        f"- thread_id: {thread_id}\n\n---\n\n"
    )
    safe_write_text(UNREAD_FILE, header + normalized + "\n")
    append_text_safely(GROUP_FILE, normalized + "\n")
    update_wechat_join_state(
        user_has_joined=False,
        first_reaction_done=False,
        mode="unread_feedback",
    )


def append_interactive_group_reply(content: str) -> None:
    if not content.strip():
        return
    normalized = _ensure_all_roles_reply(content)
    append_text_safely(GROUP_FILE, normalized + "\n")
    unread = read_wechat_unread()
    if has_wechat_unread():
        safe_write_text(UNREAD_FILE, unread + "\n\n" + normalized + "\n")
    else:
        safe_write_text(UNREAD_FILE, normalized + "\n")


def append_wechat_messages(content: str) -> None:
    append_new_wechat_feedback(content)


def clear_wechat_unread() -> None:
    safe_write_text(UNREAD_FILE, "# 未读消息\n\n> 暂无未读消息。\n")


def reset_wechat_group() -> None:
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    if GROUP_FILE.is_file():
        old_content = GROUP_FILE.read_text(encoding="utf-8")
        archive_path = ARCHIVE_DIR / f"wechat_group_{ts}.md"
        safe_write_text(archive_path, old_content)
        safe_write_text(GROUP_FILE, "")

    if UNREAD_FILE.is_file():
        safe_write_text(UNREAD_FILE, "# 未读消息\n\n> 暂无未读消息。\n")

    update_wechat_join_state(False, False, "interactive_group")
    ensure_wechat_group_bootstrapped()


def mark_wechat_read() -> None:
    clear_wechat_unread()


def read_wechat_state() -> dict:
    raw = _load_text(STATE_FILE)
    if not raw:
        return {
            "user_has_joined": False,
            "first_join_done": False,
            "mode": "unread_feedback",
        }
    joined = "user_has_joined_group: true" in raw
    first_done = "first_join_reaction_done: true" in raw
    mode = "interactive_group"
    if "mode: unread_feedback" in raw:
        mode = "unread_feedback"
    elif "mode: first_user_join" in raw:
        mode = "first_user_join"
    return {
        "user_has_joined": joined,
        "first_join_done": first_done,
        "mode": mode,
    }


def write_wechat_state(user_has_joined: bool, first_join_done: bool, mode: str):
    content = f"""# 微信群状态
## 可见性状态
- user_has_joined_group: {"true" if user_has_joined else "false"}
- first_join_reaction_done: {"true" if first_join_done else "false"}

## 当前群聊模式
- mode: {mode}

## 群聊边界
- 群聊用于课后反馈、复盘、轻互动和学习动力。
- 不替代正式教学。
- 不进行无关剧情闲聊。
- 不编造用户没有表达过的感受。
- close 模式可以提供更贴近的陪伴氛围，但不生成成人内容，不模拟现实恋人身份。
"""
    safe_write_text(STATE_FILE, content)


def append_user_group_message(user_text: str):
    ensure_wechat_group_bootstrapped()
    ts = datetime.now().strftime("%m-%d %H:%M")
    message = f"\n\n【用户】 {ts}\n{user_text}"
    if GROUP_FILE.is_file():
        current = GROUP_FILE.read_text(encoding="utf-8")
        safe_write_text(GROUP_FILE, current + message)
    else:
        safe_write_text(GROUP_FILE, f"# 学习伙伴群\n{message}")


def generate_interactive_wechat_reply(
    user_text: str,
    model_profile: ModelProfile = "flash",
    relationship_mode: str | None = None,
) -> str:
    messages, _is_first = _build_interactive_messages(user_text, relationship_mode)
    raw = chat(messages, temperature=0.7, model_profile=model_profile)
    return _ensure_all_roles_reply(raw.strip())


def generate_interactive_wechat_reply_stream(
    user_text: str,
    model_profile: ModelProfile = "flash",
    relationship_mode: str | None = None,
):
    messages, is_first = _build_interactive_messages(user_text, relationship_mode)
    return stream_chat(messages, temperature=0.7, model_profile=model_profile), is_first


def normalize_interactive_wechat_reply(content: str) -> str:
    return _ensure_all_roles_reply(content)


def search_wechat(keyword: str, max_results: int = 10) -> list[dict]:
    content = read_wechat_group()
    if not content:
        return []
    results = []
    for speaker, text in _message_blocks(content):
        if keyword.lower() in text.lower():
            results.append({"speaker": speaker, "text": text.strip()[:150]})
            if len(results) >= max_results:
                break
    return results


def summarize_wechat(max_chars: int = 500) -> str:
    content = read_wechat_group()
    if not content:
        return "暂无群聊记录"
    lines = content.splitlines()
    dividers = [i for i, line in enumerate(lines) if "---" in line or "课后反馈" in line]
    start = dividers[-1] if dividers else max(0, len(lines) - 60)
    recent = "\n".join(lines[start:])
    return recent[:max_chars] + ("..." if len(recent) > max_chars else "")


def count_wechat_messages(content: str) -> int:
    if not content.strip():
        return 0
    return len(_message_blocks(content))
