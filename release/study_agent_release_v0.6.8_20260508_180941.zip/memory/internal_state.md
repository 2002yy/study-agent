# 内部状态

## 当前运行模式
- memory_mode: preview
- route_mode: auto_rule
- debug_mode: false
- safe_mode: false
- performance_mode: fast
- entry_mode: wechat

## 当前阶段
- current_version: v0.6.8
- active_task: 文件写入稳定性、LLM client 刷新、打包安全与刷新体验收口
- next_version: v0.6.9

## 规则边界
- 不自动污染长期记忆。
- 不绕过用户确认写入。
- 不让群聊替代正式学习。
- 不让互动氛围削弱纠错和任务边界。
- safe_mode=true 时禁止写入长期记忆。
