import pytest
from pathlib import Path
from src.wechat import (
    _clean_article_text,
    append_wechat_messages,
    enrich_news_items_with_article_text,
    read_wechat_unread,
    clear_wechat_unread,
)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
GROUP = PROJECT_ROOT / "chat" / "wechat_group.md"
UNREAD = PROJECT_ROOT / "chat" / "wechat_unread.md"
STATE = PROJECT_ROOT / "chat" / "wechat_state.md"


@pytest.fixture(autouse=True)
def _save_restore():
    """备份原文件，测试结束后恢复"""
    gb = GROUP.read_text(encoding="utf-8") if GROUP.is_file() else ""
    ub = UNREAD.read_text(encoding="utf-8") if UNREAD.is_file() else ""
    sb = STATE.read_text(encoding="utf-8") if STATE.is_file() else ""
    yield
    GROUP.write_text(gb, encoding="utf-8")
    UNREAD.write_text(ub, encoding="utf-8")
    STATE.write_text(sb, encoding="utf-8")


def test_unread_has_metadata_header():
    append_wechat_messages("【三月七】\n测试\n\n【刻晴】\n测试")
    content = read_wechat_unread()
    assert "# 微信群未读消息" in content
    assert "生成时间:" in content
    assert "状态: unread" in content


def test_unread_has_four_roles():
    sample = "【三月七】\na\n\n【刻晴】\nb\n\n【纳西妲】\nc\n\n【流萤】\nd"
    append_wechat_messages(sample)
    content = read_wechat_unread()
    for role in ["【三月七】", "【刻晴】", "【纳西妲】", "【流萤】"]:
        assert role in content, f"缺失角色: {role}"


def test_unread_not_empty():
    append_wechat_messages("【流萤】\n测试内容")
    content = read_wechat_unread()
    assert len(content) > 0


def test_group_preserved_after_clear():
    gb = GROUP.read_text(encoding="utf-8")
    append_wechat_messages("【流萤】\nunique_test_marker")
    clear_wechat_unread()
    after = GROUP.read_text(encoding="utf-8")
    assert "unique_test_marker" in after


def test_clean_article_text_drops_too_short_text():
    assert _clean_article_text("太短") == ""


def test_enrich_news_items_falls_back_when_article_unavailable(monkeypatch):
    from src import wechat

    monkeypatch.setattr(wechat, "fetch_article_text", lambda *args, **kwargs: "")

    items = [{"title": "测试新闻", "link": "https://example.com/a"}]
    enriched = enrich_news_items_with_article_text(items)

    assert enriched[0]["article_excerpt"] == ""
    assert "正文不可用" in enriched[0]["article_status"]
