import pathlib
import re
import sys
import zipfile


root = pathlib.Path(sys.argv[1])
dest = pathlib.Path(sys.argv[2])
dest.parent.mkdir(parents=True, exist_ok=True)
include_tests = sys.argv[3] == "1"

EXCLUDE_DIRS = {
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    ".git",
    ".github",
    ".vscode",
    ".idea",
    "venv",
    ".venv",
    "env",
    "node_modules",
    "logs",
    "backups",
    "release",
    "dist",
    "build",
    "图片资料",
}
EXCLUDE_KEYWORDS = ["visual_assets_pack"]
SKIP_SECRET_SCAN_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".docx"}
SECRET_PATTERNS = [
    re.compile(r"sk-proj-[A-Za-z0-9_\-]{20,}"),
    re.compile(r"sk-[A-Za-z0-9_\-]{30,}"),
]


def should_exclude(rel: pathlib.Path) -> bool:
    posix = rel.as_posix()
    parts = rel.parts
    if parts[0] in EXCLUDE_DIRS:
        return True
    if posix.startswith("chat/archive/"):
        return True
    for kw in EXCLUDE_KEYWORDS:
        if kw in posix:
            return True
    if rel.suffix in (".pyc", ".pyo", ".bak"):
        return True
    if rel.name == ".env":
        return True
    if rel.name.startswith(".env.") and rel.name not in {".env.example"}:
        return True
    if rel.name.endswith(".zip"):
        return True
    if not include_tests and parts[0] == "tests":
        return True
    for part in parts:
        if part in EXCLUDE_DIRS:
            return True
    return False


def scan_secret(path: pathlib.Path) -> None:
    if path.suffix.lower() in SKIP_SECRET_SCAN_SUFFIXES:
        return
    rel = path.relative_to(root).as_posix()
    if rel in {".env.example"}:
        return
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return
    for pat in SECRET_PATTERNS:
        if pat.search(text):
            print("ERROR: possible API key in", rel, file=sys.stderr)
            sys.exit(1)


with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
    count = 0
    for file_path in sorted(root.rglob("*")):
        if not file_path.is_file():
            continue
        rel = file_path.relative_to(root)
        if should_exclude(rel):
            continue
        scan_secret(file_path)
        entry = rel.as_posix()
        zf.write(file_path, entry)
        count += 1
    names = zf.namelist()

for path in names:
    if "\\" in path:
        print("ERROR: backslash path:", path, file=sys.stderr)
        sys.exit(1)
    if path == ".env" or path.endswith("/.env"):
        print("ERROR: .env in zip:", path, file=sys.stderr)
        sys.exit(1)

required = ["app.py", "requirements.txt", ".env.example", "src/wechat.py"]
missing = [item for item in required if item not in names]
if missing:
    print("ERROR: missing:", missing, file=sys.stderr)
    sys.exit(1)

print("OK:", count, "files, forward-slash verified")
