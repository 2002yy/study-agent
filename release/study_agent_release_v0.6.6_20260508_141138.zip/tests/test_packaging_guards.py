from pathlib import Path


def test_sidebar_save_uses_session_id():
    text = Path("src/ui/sidebar.py").read_text(encoding="utf-8")
    assert "save(st.session_state.session_id)" in text
    assert "path = save()" not in text


def test_wechat_panel_no_duplicate_render_call():
    text = Path("src/ui/wechat_panel.py").read_text(encoding="utf-8")
    needle = "_render_wechat_stream(content_placeholder, content)\n    _render_wechat_stream(content_placeholder, content)"
    assert needle not in text


def test_package_helper_excludes_env_variants_and_archive():
    text = Path("tools/package_project_helper.py").read_text(encoding="utf-8")
    assert 'rel.name.startswith(".env.")' in text
    assert 'posix.startswith("chat/archive/")' in text


def test_package_script_has_python_fallback_candidates():
    text = Path("tools/package_project.ps1").read_text(encoding="utf-8")
    assert '$candidates = @("python", "py", "python3")' in text
    assert '$result = & $PythonCmd $HelperScript $Root $OutputZip $includeTestsFlag 2>&1' in text


def test_package_helper_required_files_are_locked():
    text = Path("tools/package_project_helper.py").read_text(encoding="utf-8")
    assert 'required = ["app.py", "requirements.txt", ".env.example", "src/wechat.py"]' in text
    assert 'missing = [item for item in required if item not in names]' in text


def test_package_helper_exclude_rules_are_locked():
    text = Path("tools/package_project_helper.py").read_text(encoding="utf-8")
    assert '"图片资料"' in text
    assert 'if posix.startswith("chat/archive/"):' in text
    assert 'if rel.name.startswith(".env.") and rel.name not in {".env.example"}:' in text
